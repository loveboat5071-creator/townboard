document.addEventListener('DOMContentLoaded', function () {
  const API_BASE_URL = 'https://ws-focus.vercel.app';

  var authContainer = document.getElementById('authContainer');
  var appContainer = document.getElementById('appContainer');
  var loginIdInput = document.getElementById('loginId');
  var loginPasswordInput = document.getElementById('loginPassword');
  var loginBtn = document.getElementById('loginBtn');
  var loginError = document.getElementById('loginError');
  var logoutBtn = document.getElementById('logoutBtn');

  var miningToggle = document.getElementById('miningToggle');
  var miningStatusText = document.getElementById('miningStatusText');
  var adCountDisplay = document.getElementById('adCount');
  var recentList = document.getElementById('recentList');

  var clearBtn = document.getElementById('clearBtn');
  var uploadBtn = document.getElementById('uploadBtn');
  var downloadBtn = document.getElementById('downloadBtn');

  var progressArea = document.getElementById('progressArea');
  var progressBar = document.getElementById('progressBar');
  var progressText = document.getElementById('progressText');
  var progressPercent = document.getElementById('progressPercent');

  var masterToggle = document.getElementById('masterToggle');
  var masterStatusText = document.getElementById('masterStatusText');
  var subControls = document.getElementById('subControls');

  var pauseBtn = document.getElementById('pauseBtn');

  var scrollToggle = document.getElementById('scrollToggle');
  var scrollStatusText = document.getElementById('scrollStatusText');
  var scrollControls = document.getElementById('scrollControls');

  setAuthView(false);

  loginBtn.addEventListener('click', async function () {
    loginError.style.display = 'none';
    const username = String(loginIdInput.value || '').trim();
    const password = String(loginPasswordInput.value || '').trim();

    if (!username || !password) {
      loginError.textContent = '아이디와 비밀번호를 입력해주세요.';
      loginError.style.display = 'block';
      return;
    }

    loginBtn.disabled = true;
    loginBtn.textContent = '확인 중...';

    try {
      const res = await fetch(`${API_BASE_URL}/api/ad-miner/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
      });
      const data = await res.json();
      if (!res.ok || !data.success || !data.token) {
        throw new Error(data.error || '로그인 실패');
      }

      await chrome.storage.local.set({ minerAuthToken: data.token });
      loginPasswordInput.value = '';
      setAuthView(true);
      initUI();
    } catch (err) {
      loginError.textContent = err.message || '로그인에 실패했습니다.';
      loginError.style.display = 'block';
    } finally {
      loginBtn.disabled = false;
      loginBtn.textContent = '로그인';
    }
  });

  logoutBtn.addEventListener('click', async function () {
    await chrome.storage.local.remove(['minerAuthToken']);
    setAuthView(false);
    loginPasswordInput.value = '';
  });

  chrome.storage.local.get(['minerAuthToken'], (result) => {
    if (result.minerAuthToken) {
      setAuthView(true);
      initUI();
    }
  });

  // 저장소 변경 감지
  chrome.storage.onChanged.addListener(function (changes, namespace) {
    if (namespace === 'local') {
      // [FIX] Listen for collectedAds instead of adData
      if (changes.collectedAds) {
        updateCountAndList(changes.collectedAds.newValue || []);
      }
      if (changes.isEnabled) {
        updateMasterStatus(changes.isEnabled.newValue);
      }
      // [FIX] Listen for changes to isMining, isPaused, AND isAutoScroll
      if (changes.isMining || changes.isPaused || changes.isAutoScroll) {
        chrome.storage.local.get(['isMining', 'isPaused', 'isAutoScroll'], (res) => {
          updateScrollStatus(res.isAutoScroll);

          // [FIX v4.5] Ensure correct status priority
          // If enabled && mining && !paused -> RUNNING
          // If enabled && mining && paused -> PAUSED
          // If enabled && !mining -> STOPPED
          if (res.isMining) {
            updateStatusText(true, res.isPaused);
          } else {
            updateStatusText(false, false);
          }
        });
      }
    }
  });

  // 🚀 일시정지 버튼
  pauseBtn.addEventListener('click', function () {
    chrome.storage.local.get(['isPaused'], (res) => {
      const newState = !res.isPaused;
      chrome.storage.local.set({ isPaused: newState });
      pauseBtn.textContent = newState ? '▶️' : '⏸️';
    });
  });

  // 라이브 상태 동기화 (content.js -> popup.js)
  chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
    if (message.action === 'minerStatus') {
      const stateEl = document.getElementById('popup-miner-state');
      const subEl = document.getElementById('popup-miner-sub');
      const headEl = document.getElementById('popup-miner-headline');

      if (stateEl) {
        stateEl.textContent = message.state;
        if (message.color) stateEl.style.color = message.color;
      }
      if (subEl) {
        subEl.textContent = message.sub;
      }
      if (headEl) {
        if (message.headline) {
          headEl.textContent = `BODY: "${message.headline}"`;
          headEl.style.display = 'block';
        } else {
          headEl.style.display = 'none';
        }
      }
    }
  });

  // 마스터 토글
  masterToggle.addEventListener('change', function (e) {
    var isEnabled = e.target.checked;
    updateMasterStatus(isEnabled);
    chrome.storage.local.set({ isEnabled: isEnabled });
  });

  // 채굴 토글 스위치
  miningToggle.addEventListener('change', function (e) {
    var isMining = e.target.checked;
    chrome.storage.local.set({ isMining: isMining, isPaused: false });
    // [FIX] Don't update UI manually here, let the storage listener handle it
  });

  // [NEW] 자동 스크롤 토글 스위치
  scrollToggle.addEventListener('change', function (e) {
    var isAutoScroll = e.target.checked;
    chrome.storage.local.set({ isAutoScroll: isAutoScroll });
  });

  // CSV 다운로드
  downloadBtn.addEventListener('click', function () {
    chrome.storage.local.get(['collectedAds'], function (result) {
      exportToCsv(result.collectedAds || []);
    });
  });

  // 전체 삭제
  // 전체 삭제
  clearBtn.addEventListener('click', function () {
    if (confirm('수집된 모든 데이터를 삭제하시겠습니까?')) {
      chrome.storage.local.set({ collectedAds: [] }, function () {
        updateCountAndList([]);
        // 🚀 Broadcast Reset to Content Scripts
        chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
          if (tabs && tabs[0]) {
            chrome.tabs.sendMessage(tabs[0].id, { action: 'RESET_STATE' }).catch(() => { });
          }
        });
      });
    }
  });

  // 서버 전송 (AI 분석)
  uploadBtn.addEventListener('click', function () {
    chrome.storage.local.get(['collectedAds'], function (result) {
      var data = result.collectedAds || [];
      var toSend = data.filter(item => item.status !== 'sent');

      if (toSend.length === 0) {
        alert('전송할 새로운 데이터가 없습니다.');
        return;
      }

      syncData(data);
    });
  });

  // Listen for background progress
  chrome.runtime.onMessage.addListener((message) => {
    if (message.action === 'SYNC_PROGRESS') {
      progressArea.style.display = 'block';
      uploadBtn.disabled = true;

      // Completed
      if (message.text === 'msg_complete') {
        const { success, fail } = message.extra;
        progressBar.style.width = '100%';
        progressPercent.textContent = '100%';
        progressText.textContent = '완료!';

        setTimeout(() => {
          progressArea.style.display = 'none';
          uploadBtn.disabled = false;
          alert(`동기화 완료! (백그라운드)\n- 성공: ${success}건\n- 실패: ${fail}건`);
          chrome.storage.local.get(['collectedAds'], (res) => renderRecentList(res.collectedAds || []));
        }, 500);
      } else {
        // In Progress
        progressText.textContent = message.text;
        progressBar.style.width = message.percent + '%';
        progressPercent.textContent = message.percent + '%';
      }
    }
  });

  function syncData(allData) {
    if (!confirm(allData.filter(i => i.status !== 'sent').length + '개의 데이터를 백그라운드에서 전송합니다.\n(팝업을 닫아도 전송은 계속됩니다.)')) return;

    uploadBtn.disabled = true;
    progressArea.style.display = 'block';
    progressText.textContent = "백그라운드 작업 시작 중...";

    chrome.runtime.sendMessage({ action: 'START_FULL_SYNC' }, (res) => {
      // Just triggered. Updates will come via onMessage.
      console.log('Background sync triggered');
    });
  }

  function initUI() {
    // [FIX] Load collectedAds
    chrome.storage.local.get(['collectedAds', 'isMining', 'isEnabled', 'isPaused', 'isAutoScroll'], function (result) {
      var data = result.collectedAds || [];
      var isMining = result.isMining || false;
      var isEnabled = result.isEnabled !== false;
      var isPaused = result.isPaused || false;
      var isAutoScroll = result.isAutoScroll !== false; // Default true

      updateCountAndList(data);

      masterToggle.checked = isEnabled;
      updateMasterStatus(isEnabled);

      miningToggle.checked = isMining;
      updateStatusText(isMining, isPaused);

      pauseBtn.textContent = isPaused ? '▶️' : '⏸️';

      // [NEW] Init Scroll Toggle
      scrollToggle.checked = isAutoScroll;
      updateScrollStatus(isAutoScroll);
    });
  }

  function updateMasterStatus(isEnabled) {
    if (isEnabled) {
      masterStatusText.textContent = '기능 활성화 중';
      subControls.style.opacity = '1';
      subControls.style.pointerEvents = 'auto';
      // [FIX] Update scroll controls visibility too
      if (scrollControls) {
        scrollControls.style.opacity = '1';
        scrollControls.style.pointerEvents = 'auto';
      }

      chrome.storage.local.get(['isMining', 'isPaused', 'isAutoScroll'], (res) => {
        updateStatusText(res.isMining, res.isPaused);
        updateScrollStatus(res.isAutoScroll);
      });
    } else {
      masterStatusText.textContent = '익스텐션 비활성 상태';
      subControls.style.opacity = '0.5';
      subControls.style.pointerEvents = 'none';
      miningStatusText.textContent = 'DISABLED';
      miningStatusText.className = 'mining-off';
      pauseBtn.style.display = 'none';

      // [FIX] Disable scroll controls visually
      if (scrollControls) {
        scrollControls.style.opacity = '0.5';
        scrollControls.style.pointerEvents = 'none';
      }
    }
  }


  function updateCountAndList(data) {
    adCountDisplay.textContent = data.length;
    renderRecentList(data);
  }

  function updateStatusText(isMining, isPaused) {
    if (!masterToggle.checked) return;

    if (isMining) {
      if (isPaused) {
        miningStatusText.textContent = 'PAUSED';
        miningStatusText.className = 'mining-off';
        miningStatusText.style.color = '#ffa000';
        pauseBtn.textContent = '▶️';
      } else {
        miningStatusText.textContent = 'ON';
        miningStatusText.className = 'mining-on';
        miningStatusText.style.color = '';
        pauseBtn.textContent = '⏸️';
      }
      pauseBtn.style.display = 'block';
    } else {
      miningStatusText.textContent = 'OFF';
      miningStatusText.className = 'mining-off';
      miningStatusText.style.color = '';
      pauseBtn.style.display = 'none';
    }
  }

  function updateScrollStatus(isAutoScroll) {
    if (!scrollStatusText) return;
    if (isAutoScroll === false) { // Explicit false check
      scrollStatusText.textContent = 'OFF';
      scrollStatusText.style.color = '#757575';
    } else {
      scrollStatusText.textContent = 'ON';
      scrollStatusText.style.color = '#4caf50';
    }
  }

  function renderRecentList(data) {
    recentList.innerHTML = '';
    if (!data || data.length === 0) {
      var emptyMsg = document.createElement('div');
      emptyMsg.style.textAlign = 'center';
      emptyMsg.style.color = '#999';
      emptyMsg.style.padding = '10px';
      emptyMsg.textContent = '수집된 데이터 없음';
      recentList.appendChild(emptyMsg);
      return;
    }

    var fullData = data.slice().reverse();
    fullData.forEach(function (item, index) {
      var originalIndex = data.length - 1 - index;
      var container = document.createElement('div');
      container.className = 'recent-item';
      container.style.cssText = 'display: flex; justify-content: space-between; align-items: center; padding: 8px 0; border-bottom: 1px solid #eee;';

      if (item.status === 'sent') {
        container.style.opacity = '0.7';
        container.style.borderLeft = '4px solid #4caf50';
        container.style.backgroundColor = '#f1f8f1';
      }

      var contentDiv = document.createElement('div');

      // [FIX] Schema Mapping for v3.8+ (Aligned with Server)
      var brandName = item.videoTitle || item.brandName || item.domain || 'Unknown Brand';
      var cta = item.ctaText || 'Visit Site';
      var landingPage = item.landingUrl || item.landingPage || '#';
      var videoLink = item.youtubeLink || item.videoUrl;

      // Line 1: Brand (Bold)
      var displayTitle = brandName;
      if (displayTitle.length > 30) displayTitle = displayTitle.substring(0, 30) + '...';

      var titleDiv = document.createElement('div');
      titleDiv.style.fontWeight = 'bold';
      titleDiv.style.fontSize = '12px';
      titleDiv.textContent = displayTitle;

      // Line 2: CTA | URL (Grey)
      var infoDiv = document.createElement('div');
      infoDiv.style.color = '#666';
      infoDiv.style.fontSize = '11px';

      // Extract hostname for display
      let displayUrl = landingPage;
      try {
        if (landingPage.startsWith('http')) {
          displayUrl = new URL(landingPage).hostname;
        }
      } catch (e) { }

      var subText = cta + ' | ' + displayUrl;
      if (subText.length > 45) subText = subText.substring(0, 45) + '...';
      infoDiv.textContent = subText;

      // Line 3: Video Link
      if (videoLink) {
        var ytLink = document.createElement('a');
        ytLink.href = videoLink;
        ytLink.target = '_blank';
        ytLink.textContent = ' 🎞️';
        ytLink.style.textDecoration = 'none';

        // Prevent click bubbling
        ytLink.onclick = (e) => e.stopPropagation();

        titleDiv.appendChild(ytLink);
      }

      contentDiv.appendChild(titleDiv);
      contentDiv.appendChild(infoDiv);

      var delBtn = document.createElement('button');
      delBtn.innerText = '✕';
      delBtn.style.cssText = 'border: none; background: none; color: #ff5252; cursor: pointer; font-weight: bold; padding: 0 5px;';
      delBtn.onclick = function (e) {
        e.stopPropagation();
        deleteItem(originalIndex);
      };

      container.appendChild(contentDiv);
      container.appendChild(delBtn);
      recentList.appendChild(container);
    });
  }

  // Delete Item
  function deleteItem(index) {
    chrome.storage.local.get(['collectedAds'], function (result) {
      var data = result.collectedAds || [];
      if (index >= 0 && index < data.length) {
        data.splice(index, 1);
        chrome.storage.local.set({ collectedAds: data });
      }
    });
  }

  // Clear All
  clearBtn.addEventListener('click', function () {
    if (confirm('모든 수집 데이터를 삭제하시겠습니까?')) {
      chrome.storage.local.set({ collectedAds: [] });
    }
  });

  function exportToCsv(data) {
    if (!data.length) { alert('데이터가 없습니다.'); return; }

    // [FIX] Update CSV Map for v3.8+
    var csv = "\uFEFF수집일시,브랜드,CTA/버튼,랜딩URL,Shorts링크\n";
    data.forEach(function (e) {
      csv += [
        e.timestamp,
        escapeCsv(e.videoTitle || e.brandName || e.domain),
        escapeCsv(e.ctaText),
        escapeCsv(e.landingUrl || e.landingPage),
        escapeCsv(e.youtubeLink || e.videoUrl)
      ].join(",") + "\n";
    });

    var blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    var url = URL.createObjectURL(blob);
    var link = document.createElement("a");
    link.href = url;
    link.download = 'shorts_ad_leads_' + new Date().toISOString().slice(0, 10) + '.csv';
    link.click();
  }

  function escapeCsv(text) {
    if (!text) return "";
    return '"' + String(text).replace(/"/g, '""') + '"';
  }

  function setAuthView(isAuthenticated) {
    authContainer.style.display = isAuthenticated ? 'none' : 'block';
    appContainer.style.display = isAuthenticated ? 'block' : 'none';
    logoutBtn.style.display = isAuthenticated ? 'block' : 'none';
  }
});
