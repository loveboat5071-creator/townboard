chrome.runtime.onInstalled.addListener(() => {
  // 기본값 설정
  chrome.storage.local.get(['collectedAds', 'isMining'], (result) => {
    if (!result.collectedAds) chrome.storage.local.set({ collectedAds: [] });
    if (result.isMining === undefined) chrome.storage.local.set({ isMining: true });
  });
});

// 메시지 수신 (배지 업데이트, 페이지 타이틀 가져오기, API 전송)
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'updateBadge') {
    updateBadge(request.text);
    return false; // 동기 처리
  }

  // (New) 페이지 타이틀 가져오기 (CORS 우회를 위해 여기서 수행)
  if (request.action === 'FETCH_PAGE_TITLE') {
    // [v5.4] Fix: Capture finalUrl BEFORE consuming response body
    fetch(request.url, { redirect: 'follow' })
      .then(response => {
        const finalUrl = response.url; // Capture URL before .text()
        return response.text().then(html => ({ html, finalUrl }));
      })
      .then(({ html, finalUrl }) => {
        // <title> 태그 추출 (간단한 정규식)
        const matches = html.match(/<title>([^<]*)<\/title>/i);
        const pageTitle = matches ? matches[1].trim() : "";
        console.log('[BG] v5.4 Resolved:', finalUrl);
        sendResponse({ pageTitle: pageTitle, finalUrl: finalUrl });
      })
      .catch(err => {
        console.warn('Title Fetch Fail:', err);
        sendResponse({ pageTitle: "", finalUrl: null });
      });
    return true; // 비동기 응답 필수
  }

  // (New) API 데이터 전송 (Mixed Content 우회)
  if (request.action === 'SEND_AD_DATA') {
    sendOneItem(request.data).then(res => sendResponse(res));
    return true;
  }

  // 🚀 (New) 백그라운드 전체 동기화 (팝업 닫아도 유지됨)
  if (request.action === 'START_FULL_SYNC') {
    // [FIX] Use 'return true' to keep Service Worker alive during the async operation
    runBackgroundSync().then(() => {
      sendResponse({ completed: true });
    });
    return true; // Indicates async response, keeps SW alive
  }
});

// 단일 아이템 전송 함수 (기존 로직 분리)
async function sendOneItem(item) {
  const authState = await chrome.storage.local.get(['minerAuthToken']);
  const token = authState.minerAuthToken;
  if (!token) {
    return { success: false, error: '로그인이 필요합니다.' };
  }

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 30000);

  try {
    const res = await fetch(`${API_BASE_URL}/api/ad-miner`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify(item),
      signal: controller.signal
    });

    clearTimeout(timeoutId);
    if (!res.ok) {
      const txt = await res.text();
      throw new Error(`Server Error (${res.status}): ${txt}`);
    }
    const json = await res.json();
    return { success: true, data: json };
  } catch (err) {
    clearTimeout(timeoutId);
    console.error('API Send Error:', err);
    return { success: false, error: err.name === 'AbortError' ? 'Timeout' : err.toString() };
  }
}

// 백그라운드 루프 실행
async function runBackgroundSync() {
  console.log('[BG] Starting Full Sync...');

  // 1. 데이터 가져오기
  const result = await chrome.storage.local.get(['collectedAds']);
  let adData = result.collectedAds || [];

  // 2. 전송 대상 필터링
  const toSend = adData.filter(item => item.status !== 'sent');
  const total = toSend.length;

  if (total === 0) {
    broadcastProgress(100, 0, 0, '전송할 데이터 없음');
    return;
  }

  let successCount = 0;
  let failCount = 0;

  for (let i = 0; i < total; i++) {
    const item = toSend[i];

    // 진행상황 알림
    const percent = Math.round(((i + 1) / total) * 100);
    broadcastProgress(percent, i + 1, total, `전송 중: ${item.channelName || item.brandName || item.videoTitle || '분석 중...'}`);

    const res = await sendOneItem(item);

    if (res.success) {
      successCount++;
      // [Safety] 성공 시마다 최신 스토리지 다시 읽고 업데이트 (데이터 충돌 방지)
      const freshRes = await chrome.storage.local.get(['collectedAds']);
      const freshData = freshRes.collectedAds || [];

      const targetIndex = freshData.findIndex(d =>
        (d.timestamp === item.timestamp && d.rawLink === item.rawLink) ||
        (d.landingUrl === item.landingUrl && d.domain === item.domain)
      );

      if (targetIndex > -1) {
        freshData[targetIndex].status = 'sent';
        await chrome.storage.local.set({ collectedAds: freshData });
      }
    } else {
      failCount++;
    }
  }

  // 완료 알림
  broadcastProgress(100, total, total, 'msg_complete', { success: successCount, fail: failCount });
  console.log(`[BG] Sync Done. Success: ${successCount}, Fail: ${failCount}`);
}

function broadcastProgress(percent, current, total, text, extra = null) {
  chrome.runtime.sendMessage({
    action: 'SYNC_PROGRESS',
    percent: percent,
    current: current,
    total: total,
    text: text,
    extra: extra
  }).catch(() => { }); // 팝업이 닫혀있으면 무시됨
}

// 저장소 변경 감지 (배지 자동 동기화)
chrome.storage.onChanged.addListener((changes, namespace) => {
  if (namespace === 'local' && changes.collectedAds) {
    const newData = changes.collectedAds.newValue || [];
    updateBadge(newData.length);
  }
});

function updateBadge(count) {
  const text = count > 0 ? count.toString() : '';
  chrome.action.setBadgeText({ text: text });
  chrome.action.setBadgeBackgroundColor({ color: '#FF0000' });
}
const API_BASE_URL = 'https://ws-focus.vercel.app';
