// YouTube Shorts Ad Miner for WS MEDIA - Re-architected Version
// Directive: DOM-Independent, Network-Destination Based, SPA-Resilient
// Version: 3.0 (Clean Rewrite)

class ShortsMiner {
  constructor() {
    this.state = {
      isEnabled: true, // Master Switch
      isMining: true,
      isPaused: false,
      isAutoScroll: true,
      lastWasAd: false, // [v3.7] Guard against lingering components
      currentUrl: location.href,
      currentVideoId: null,
      status: 'IDLE' // IDLE, SCANNING, AD_FOUND, SKIPPING
    };

    this.overlay = null;
    this.scanInterval = null;
    this.collectedAds = [];

    this.init();
  }

  init() {
    console.log('[Miner] Initializing v5.4 (BG Scope Fix)...');
    this.createOverlay();

    // Load Settings
    chrome.storage.local.get(['isEnabled', 'isMining', 'isAutoScroll', 'collectedAds'], (res) => {
      this.state.isEnabled = res.isEnabled !== false;
      this.state.isMining = res.isMining !== false; // Restore isMining
      this.state.isAutoScroll = res.isAutoScroll !== false;
      this.collectedAds = res.collectedAds || [];

      this.updateOverlay();
      this.toggleVisibility(this.state.isEnabled);

      if (this.state.isEnabled && this.state.isMining) this.startLoop();
    });

    // Message Listener
    chrome.runtime.onMessage.addListener((req, sender, sendResponse) => {
      if (req.action === 'toggleMining') {
        this.state.isMining = req.status;
        (this.state.isEnabled && this.state.isMining) ? this.startLoop() : this.stopLoop();
        this.updateOverlay();
      } else if (req.action === 'toggleAutoScroll') {
        this.state.isAutoScroll = req.enabled;
        this.updateOverlay();
      } else if (req.action === 'exportData') {
        sendResponse({ ads: this.collectedAds });
      } else if (req.action === 'ping') { // Heartbeat
        this.updateOverlay(); // Force status update
      }
    });

    // Storage Listener to sync popup toggles
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local') return;

      // Master Switch
      if (changes.isEnabled) {
        this.state.isEnabled = changes.isEnabled.newValue;
        this.toggleVisibility(this.state.isEnabled);
        if (!this.state.isEnabled) this.stopLoop();
        else if (this.state.isMining) this.startLoop();
      }

      if (changes.isMining) {
        this.state.isMining = changes.isMining.newValue;
        (this.state.isEnabled && this.state.isMining) ? this.startLoop() : this.stopLoop();
      }
      if (changes.isAutoScroll) this.state.isAutoScroll = changes.isAutoScroll.newValue;

      // [FIX] Sync Collected Ads (e.g. when cleared from Popup)
      if (changes.collectedAds) {
        this.collectedAds = changes.collectedAds.newValue || [];
      }

      this.updateOverlay(); // Update overlay to reflect any status change
    });
  }

  // =========================================================================
  // CORE LOOP (Single Source of Truth)
  // =========================================================================
  startLoop() {
    if (this.scanInterval) clearInterval(this.scanInterval);
    console.log('[Miner] Loop Started v3.3');

    this.scanInterval = setInterval(() => {
      if (!this.state.isEnabled || !this.state.isMining) return;

      // 1. SPA Detection
      if (location.href !== this.state.currentUrl) {
        console.log('[Miner] URL Changed');
        this.state.currentUrl = location.href;
        this.state.status = 'SCANNING';
        this.explorationCount = 0;
        return;
      }

      // 2. Active Video Detection
      const activeVideo = this.findActiveVideo();
      if (!activeVideo) {
        this.updateOverlay('대기 중...', '영상 로딩 안됨', '#999');
        return;
      }

      const videoId = this.getVideoId(activeVideo);

      // [Logic] Handle different states
      if (this.state.status === 'SKIPPING' || (this.state.currentVideoId === videoId && this.state.status === 'AD_FOUND')) {
        return; // Already done with this video
      }

      // New Video Found -> Reset
      if (this.state.currentVideoId !== videoId) {
        this.state.currentVideoId = videoId;
        this.state.status = 'SCANNING';
        this.explorationCount = 0;
        if (this.organicTimer) { clearTimeout(this.organicTimer); this.organicTimer = null; }
        console.log('[Miner] New Video:', videoId);

        // [v3.7] Sequential Ad Guard
        if (this.state.lastWasAd) {
          console.log('[Miner] Sequential Ad Guard: Forcing Organic state');
          this.state.lastWasAd = false;
          this.state.status = 'ORGANIC';
          this.updateOverlay('일반 영상 (보호 모드)', '잔상 제거 대기 및 스킵 중...', '#2196F3');
          return; // Skip scanning for this specific video
        }
      }

      // RESUME LOGIC for Organic
      if (this.state.status === 'ORGANIC') {
        if (this.state.isAutoScroll && !this.organicTimer) {
          this.scheduleOrganicSkip(activeVideo);
        }
        return;
      }

      // 3. Ad Detection & Exploration
      const adData = this.scanForAd(activeVideo);

      if (adData) {
        // [ENHANCED] Exploration Phase
        if (this.state.status !== 'EXPLORING') {
          this.state.status = 'EXPLORING';
          this.explorationCount = 0;
          if (this.organicTimer) { clearTimeout(this.organicTimer); this.organicTimer = null; }
        }

        this.explorationCount++;

        // Decide if we have enough info
        const isSolidBrand = adData.brand && !adData.brand.includes('googleadservices') && !adData.brand.includes('Unknown');
        const timeoutReached = this.explorationCount > 10; // [v4.1] Increased to ~8 seconds

        if (isSolidBrand || timeoutReached) {
          console.log(isSolidBrand ? '[Miner] Solid Brand Found!' : '[Miner] Exploration Timeout');
          this.state.status = 'AD_FOUND';
          this.handleAd(adData);
        } else {
          this.updateOverlay('광고 정보 탐색 중...', `${this.explorationCount}/5 단계`, '#4CAF50');
        }
      } else {
        // [SCANNING] -> [ORGANIC]
        if (this.state.status === 'SCANNING') {
          this.state.status = 'ORGANIC';
        }
      }

    }, 800);
  }

  toggleVisibility(show) {
    if (this.overlay) this.overlay.style.display = show ? 'block' : 'none';
  }

  stopLoop() {
    if (this.scanInterval) clearInterval(this.scanInterval);
    if (this.organicTimer) clearTimeout(this.organicTimer);
    this.updateOverlay('중지됨', '채굴 비활성화', '#666');
  }

  scheduleOrganicSkip(activeVideo) {
    if (this.organicTimer) return;

    const waitTime = Math.floor(Math.random() * 3000) + 2000; // 2s - 5s
    this.updateOverlay('일반 영상', `${(waitTime / 1000).toFixed(1)}초 후 스킵`, '#2196F3');

    this.organicTimer = setTimeout(() => {
      this.forceSkip(activeVideo);
      this.organicTimer = null;
    }, waitTime);
  }

  // Used by scanForAd to resolve Google redirects
  resolveGoogleUrl(url) {
    if (!url) return '';

    try {
      const urlObj = new URL(url);

      // [v5.2] Enhanced Base64 decoder with more patterns and substring scanning
      const aiParam = urlObj.searchParams.get('ai');
      if (aiParam) {
        console.log('[Miner] v5.2 Scanning ai param (length:', aiParam.length + ')');

        // Multiple Base64 patterns for 'http' prefix
        // 'aHR0cHM6Ly' = base64 of 'https://'
        // 'aHR0cDovL' = base64 of 'http://'
        // 'odHRwczov' = offset variant
        const base64Patterns = [
          /aHR0cHM6Ly[A-Za-z0-9_\/\-\.]+/g,  // https://
          /aHR0cDovL[A-Za-z0-9_\/\-\.]+/g,    // http://
          /odHRwczovL[A-Za-z0-9_\/\-\.]+/g,   // offset 1
          /dHRwczovL[A-Za-z0-9_\/\-\.]+/g     // offset 2
        ];

        for (const pattern of base64Patterns) {
          const matches = aiParam.match(pattern);
          if (matches && matches.length > 0) {
            // Try all matches, not just the longest
            for (const match of matches.sort((a, b) => b.length - a.length)) {
              try {
                const padded = match.replace(/-/g, '+').replace(/_/g, '/');
                const padding = '='.repeat((4 - padded.length % 4) % 4);
                const decoded = atob(padded + padding);
                // Valid URL check
                if (decoded.match(/^https?:\/\/[a-z0-9\.\-]+/i)) {
                  console.log('[Miner] v5.2 Decoded URL:', decoded);
                  // Return base URL without query params for clean display
                  const clean = decoded.split('?')[0];
                  return clean;
                }
              } catch (e) { }
            }
          }
        }

        // [v5.2] Brute force substring scan if patterns fail
        // This handles cases where URL is at different offsets
        for (let i = 0; i < aiParam.length - 20; i++) {
          for (let len = 20; len < Math.min(200, aiParam.length - i); len++) {
            try {
              const sub = aiParam.substring(i, i + len);
              const padded = sub.replace(/-/g, '+').replace(/_/g, '/');
              const padding = '='.repeat((4 - padded.length % 4) % 4);
              const decoded = atob(padded + padding);
              if (decoded.match(/^https?:\/\/[a-z0-9][a-z0-9\.\-]+\.[a-z]{2,}/i)) {
                console.log('[Miner] v5.2 Brute-force Decoded:', decoded);
                return decoded.split('?')[0];
              }
            } catch (e) { }
          }
        }
      }

      // Fallback: Check standard parameters
      const paramKeys = ['adurl', 'dst', 'destination', 'target'];
      for (const key of paramKeys) {
        if (urlObj.searchParams.has(key)) {
          let val = urlObj.searchParams.get(key);
          if (val && val.startsWith('http')) {
            return this.resolveGoogleUrl(this.decodeRecursive(val));
          }
        }
      }

    } catch (e) { console.warn('[Miner] URL Parse Error:', e); }

    return url;
  }

  // =========================================================================
  // 1. Active Video Detection (No selectors, purely heuristic)
  // =========================================================================
  findActiveVideo() {
    const videos = Array.from(document.querySelectorAll('video'));
    // Find the one that is playing AND visible in viewport
    return videos.find(v => {
      // Must have src
      if (!v.src || (!v.src.startsWith('http') && !v.src.startsWith('blob'))) return false;

      // Must not be paused (usually) OR explicitly active
      // But ads sometimes auto-pause overlay? No, ad is video.
      // Shorts usually auto-plays.

      // Check Viewport
      const rect = v.getBoundingClientRect();
      const isLargeEnough = rect.width > 50 && rect.height > 50;
      const centerVisible = rect.top < window.innerHeight / 2 && rect.bottom > window.innerHeight / 2;
      // [FIX] Relaxed Viewport Check
      const inView = (rect.top >= -200 && rect.bottom <= window.innerHeight + 200);

      return (inView || centerVisible) && isLargeEnough;
    });
  }

  getVideoId(videoEl) {
    // Try to get from closest reel container
    const reel = videoEl.closest('ytd-reel-video-renderer');
    if (reel) return reel.id || reel.getAttribute('id') || videoEl.src;
    return videoEl.src; // Fallback
  }

  // =========================================================================
  // 2. Ad Detection (Deep Recursion, Link-Based)
  // =========================================================================
  scanForAd(videoEl) {
    const reel = videoEl.closest('ytd-reel-video-renderer');
    if (!reel) return null;

    // Recursive search for 'adurl' links or specific components
    const signals = this.deepScan(reel);

    if (signals.isAd) {
      return {
        url: signals.link,
        brand: signals.brand || "Unknown Brand",
        cta: signals.cta || "Learn More"
      };
    }
    return null;
  }

  deepScan(root, depth = 0) {
    if (depth > 5) return { isAd: false };

    let result = { isAd: false, link: null, brand: null, cta: null };

    // [v5.0] Precision Selectors from Browser Inspection
    // 1. Check for yt-ad-metadata-shape (THE definitive ad indicator for Shorts)
    const adMetadata = root.querySelector ? root.querySelector('yt-ad-metadata-shape') : null;
    if (adMetadata) {
      result.isAd = true;

      // Brand name is in .yt-core-attributed-string__link inside metadata
      const brandEl = adMetadata.querySelector('.yt-core-attributed-string__link');
      if (brandEl && brandEl.textContent) {
        result.brand = brandEl.textContent.trim();
        console.log('[Miner] v5.0 Brand Found:', result.brand);
      }
    }

    // 2. Check for CTA button (ad-button-view-model)
    const ctaButton = root.querySelector ? root.querySelector('ad-button-view-model a') : null;
    if (ctaButton) {
      result.isAd = true;
      result.link = ctaButton.href;

      const ctaText = ctaButton.querySelector('.yt-core-attributed-string');
      if (ctaText) {
        result.cta = ctaText.textContent.trim();
      }
    }

    // 3. Fallback: Check for googleadservices links (older/alternative ad formats)
    if (!result.isAd) {
      const adLinks = root.querySelectorAll ? Array.from(root.querySelectorAll('a[href*="googleadservices"], a[href*="aclk"]')) : [];
      if (adLinks.length > 0) {
        result.isAd = true;
        result.link = adLinks[0].href;
      }
    }

    // 4. Shadow DOM Traversal (for nested components)
    const nodes = root.querySelectorAll ? root.querySelectorAll('*') : [];
    for (const node of nodes) {
      if (node.shadowRoot) {
        const shadowResult = this.deepScan(node.shadowRoot, depth + 1);
        if (shadowResult.isAd) {
          result.isAd = true;
          if (shadowResult.link) result.link = result.link || shadowResult.link;
          if (shadowResult.brand && (!result.brand || result.brand.includes('googleadservices'))) {
            result.brand = shadowResult.brand;
          }
          if (shadowResult.cta) result.cta = result.cta || shadowResult.cta;
        }
      }
    }

    return result;
  }

  // =========================================================================
  // 3. Ad Handling (Collect & Skip)
  // =========================================================================
  async handleAd(adData) {
    let bgResponse = null; // [FIX] Function scope for v3.8+ compatibility
    // 1. Deep URL Analysis & Recursive Decoding
    let finalUrl = this.decodeRecursive(this.resolveGoogleUrl(adData.url));

    // 2. Initial Brand Selection
    let finalBrand = adData.brand || '';

    // [v5.3] ALWAYS try to resolve googleadservices URLs via background fetch
    // This follows the actual redirect server-side to get the true destination
    const needsUrlResolution = finalUrl.includes('googleadservices') || finalUrl.includes('doubleclick');

    // [Check] If brand is generic OR URL needs resolution, fetch from background
    const isGeneric = !finalBrand ||
      /google|unknown|learn more|광고|신청하기|더 보기|visit/i.test(finalBrand) ||
      finalBrand.length < 2;

    if (isGeneric || needsUrlResolution) {
      this.updateOverlay('광고 분석 중...', '백그라운드 URL 해석 중...', '#2196F3');
      try {
        bgResponse = await new Promise((resolve) => {
          chrome.runtime.sendMessage({ action: 'FETCH_PAGE_TITLE', url: adData.url }, (res) => {
            resolve(res);
          });
          setTimeout(() => resolve(null), 4000); // 4s timeout
        });

        // [v5.3] Use the final URL from background fetch (server follows redirects)
        if (bgResponse && bgResponse.finalUrl && !bgResponse.finalUrl.includes('googleadservices')) {
          console.log('[Miner] v5.3 Background Resolved URL:', bgResponse.finalUrl);
          finalUrl = bgResponse.finalUrl;
        }

        // If brand is generic, also try to get it from page title
        if (isGeneric && bgResponse && bgResponse.pageTitle) {
          console.log('[Miner] Found Background Title:', bgResponse.pageTitle);
          finalBrand = this.cleanBrandName(bgResponse.pageTitle);
        }
      } catch (e) {
        console.warn('[Miner] FETCH_PAGE_TITLE Error:', e);
        if (e.message && e.message.includes('Extension context invalidated')) {
          this.updateOverlay('연결 끊김', '브라우저를 새로고침 해주세요', '#FF5252');
          this.stopLoop();
          return;
        }
      }
    }

    // [Fallback] Domain extraction as last resort
    // [v4.1] Expanded Ad Server List
    const isAdServer = (s) => /googleadservices|doubleclick|googlesyndication|youtube\.com|google\.com\/pagead/i.test(s);
    if (!finalBrand || isAdServer(finalBrand) || finalBrand === 'Unknown') {
      try {
        const u = new URL(finalUrl);
        const host = u.hostname.replace('www.', '').split('.')[0];
        if (!isAdServer(host)) {
          finalBrand = host.charAt(0).toUpperCase() + host.slice(1);
        } else {
          finalBrand = '광고주 정보 탐색 실패';
        }
      } catch (e) { finalBrand = '광고주 정보 없음'; }
    }

    // Final Cleaning
    finalBrand = this.cleanBrandName(finalBrand);

    // [v3.8] ALIGN FIELDS WITH SERVER
    const domainPart = () => {
      try { return new URL(finalUrl).hostname.replace('www.', ''); } catch (e) { return ''; }
    };

    const refinedAdData = {
      // Internal fields
      brandName: finalBrand,
      ctaText: adData.cta,

      // Server-aligned fields (Mapping to app/api/ad-miner/route.ts)
      videoTitle: finalBrand, // Server uses this for Advertiser Name
      channelName: finalBrand,
      landingUrl: finalUrl,
      rawLink: adData.url,
      youtubeLink: location.href,
      landingPageTitle: (bgResponse && bgResponse.pageTitle) ? bgResponse.pageTitle : finalBrand,
      domain: domainPart(),

      timestamp: new Date().toISOString(),
      status: 'pending' // For internal sync tracking
    };

    // [v4.1] Zero-Garbage Policy: Strict Validation
    // If brand is still generic or domain is an ad server, DISCARD IT.
    const isGarbage =
      !finalBrand ||
      finalBrand === 'Unknown' ||
      finalBrand === '광고주 정보 탐색 실패' ||
      finalBrand.includes('googleadservices') ||
      (refinedAdData.domain && refinedAdData.domain.includes('googleadservices'));

    // [v4.4 Debug] Force disable garbage filter
    if (false) { // was (isGarbage)
      console.warn(`[Miner] GARBAGE DETECTED. Discarding: ${finalBrand} / ${refinedAdData.domain}`);
      this.updateOverlay('수집 제외', '유효하지 않은 광고 정보', '#FF5252');

      // Skip without saving
      this.state.lastWasAd = true;
      setTimeout(() => {
        this.state.status = 'SKIPPING';
        this.forceSkip();
      }, 2000);
      return;
    }

    // 3. Collection & Storage
    const reallyNew = !this.collectedAds.some(a => a.landingUrl === refinedAdData.landingUrl);

    if (reallyNew) {
      this.collectedAds.push(refinedAdData);
      chrome.storage.local.set({ collectedAds: this.collectedAds });
      chrome.runtime.sendMessage({ action: 'minerStatus', headline: `광고 수집 완료: ${finalBrand}` });
    }

    // [v3.7] Mark that we just processed an ad
    this.state.lastWasAd = true;

    // 4. Skip Procedure
    setTimeout(() => {
      this.state.status = 'SKIPPING';
      this.updateOverlay('수집 완료', '잠시 후 다음 영상으로 이동', '#FF9800');
      this.forceSkip();
    }, 4500);
  }

  decodeRecursive(url) {
    if (!url) return '';
    let decoded = url;
    try {
      while (decoded.includes('%') && decoded !== decodeURIComponent(decoded)) {
        decoded = decodeURIComponent(decoded);
      }
    } catch (e) { }
    return decoded;
  }

  cleanBrandName(name) {
    if (!name) return 'Unknown';
    let clean = name.trim();

    // Common separators: | - : — –
    const separators = ['|', '-', ':', '—', '–'];
    for (const sep of separators) {
      if (clean.includes(sep)) {
        const parts = clean.split(sep);
        // Usually the brand is the part that isn't a slogan or "Official Site"
        // Heuristic: Use the part that doesn't contain generic keywords
        const brandCandidate = parts.find(p => !/site|official|website|home|shop|install|welcome|공식|홈페이지|쇼핑|로그인/i.test(p)) || parts[0];
        clean = brandCandidate.trim();
        break;
      }
    }

    // Final sanitization
    clean = clean.replace(/광고|Advertisement|Sponsored|Ads|스폰서|견적 요청|Learn More/g, '').trim();

    // Remove emojis and special chars
    clean = clean.replace(/[\u2700-\u27BF]|[\uE000-\uF8FF]|\uD83C[\uDC00-\uDFFF]|\uD83D[\uDC00-\uDFFF]|[\u2011-\u26FF]|\uD83E[\uDC00-\uDFFF]/g, '');

    // Capitalize first letter if it's longer than 2 chars
    if (clean.length > 2) {
      clean = clean.charAt(0).toUpperCase() + clean.slice(1);
    }

    return clean || 'Unknown';
  }


  forceSkip(activeVideo = null) { // activeVideo parameter added
    console.log('[Miner] Attempting Skip...');

    // Method 0: Use activeVideo to find 'Next' button specifically within its container?
    // Shorts are usually full screen, so global ID might work.

    // Method 1: ID-based Navigation Button (Most reliable if ID exists)
    const navDown = document.getElementById('navigation-button-down');
    if (navDown) {
      const btn = navDown.querySelector('button');
      if (btn) { btn.click(); return; }
    }

    // Method 2: Wheel Scroll (Standard behavior simulation)
    const wheelEvent = new WheelEvent('wheel', {
      deltaY: 500, // Strong scroll
      bubbles: true,
      cancelable: true,
      view: window
    });
    document.body.dispatchEvent(wheelEvent);

    // Method 3: Arrow Key (Backup)
    setTimeout(() => {
      const keyEvent = new KeyboardEvent('keydown', {
        key: 'ArrowDown',
        code: 'ArrowDown',
        keyCode: 40,
        bubbles: true,
        cancelable: true
      });
      document.body.dispatchEvent(keyEvent);
    }, 100);

    // Clear ID to allow rescan of next video
    this.state.currentVideoId = null;
  }

  // =========================================================================
  // UI Overlay
  // =========================================================================
  createOverlay() {
    if (document.getElementById('miner-overlay-v3')) return;

    const div = document.createElement('div');
    div.id = 'miner-overlay-v3';
    div.style.cssText = `
      position: fixed; bottom: 80px; right: 20px;
      background: rgba(0,0,0,0.85); color: #fff;
      padding: 14px 18px; border-radius: 12px;
      font-family: sans-serif; font-size: 15px;
      z-index: 99999; box-shadow: 0 4px 12px rgba(0,0,0,0.3);
      backdrop-filter: blur(4px); transition: all 0.3s;
      min-width: 260px;
      max-width: 360px;
    `;
    div.innerHTML = `
      <div id="miner-drag-handle" style="font-weight:bold; margin-bottom:8px; font-size:13px; color:#bbb; cursor:move; user-select:none;">⛏️ WS MEDIA Miner v1.0</div>
      <div id="miner-status-text" style="font-size:18px; font-weight:bold; line-height:1.35;">Initializing...</div>
      <div id="miner-sub-text" style="font-size:13px; color:#aaa; margin-top:4px; line-height:1.35;"></div>
    `;
    document.body.appendChild(div);
    this.overlay = div;

    const dragHandle = div.querySelector('#miner-drag-handle');
    if (dragHandle) {
      let isDragging = false;
      let offsetX = 0;
      let offsetY = 0;

      dragHandle.addEventListener('mousedown', (e) => {
        isDragging = true;
        const rect = div.getBoundingClientRect();
        offsetX = e.clientX - rect.left;
        offsetY = e.clientY - rect.top;
        div.style.right = 'auto';
        div.style.bottom = 'auto';
      });

      document.addEventListener('mousemove', (e) => {
        if (!isDragging) return;
        const x = Math.max(0, Math.min(window.innerWidth - div.offsetWidth, e.clientX - offsetX));
        const y = Math.max(0, Math.min(window.innerHeight - div.offsetHeight, e.clientY - offsetY));
        div.style.left = `${x}px`;
        div.style.top = `${y}px`;
      });

      document.addEventListener('mouseup', () => {
        isDragging = false;
      });
    }
  }

  updateOverlay(status, sub, color) {
    if (!this.overlay) return;

    // [FIX] Use current state if arguments are missing
    const displayStatus = status || this.state.status || '대기 중...';
    const displaySub = sub || '';
    let displayColor = color || (displayStatus.includes('광고') ? '#4CAF50' : '#2196F3');

    // Default color logic
    if (!color && displayStatus === 'IDLE') displayColor = '#999';

    const statusEl = document.getElementById('miner-status-text');
    const subEl = document.getElementById('miner-sub-text');

    if (statusEl) {
      statusEl.textContent = displayStatus;
      statusEl.style.color = displayColor;
    }
    if (subEl) subEl.textContent = displaySub;

    // Send Status to Popup (Runtime)
    try {
      chrome.runtime.sendMessage({
        action: 'minerStatus',
        state: displayStatus,
        sub: displaySub,
        color: displayColor
      });
    } catch (e) { }
  }
}

// Start
new ShortsMiner();
