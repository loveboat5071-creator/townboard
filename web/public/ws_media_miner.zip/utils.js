// URL 파싱 및 데이터 정제 유틸리티 함수

/**
 * 광고 URL에서 실제 도메인과 전체 URL을 추출합니다.
 * - 일반 adurl 파라미터 확인
 * - Base64로 인코딩된 숨겨진 URL 탐색 (aHR0...)
 */
function extractRealUrl(rawUrl) {
  try {
    if (!rawUrl) return { domain: null, fullUrl: null };

    // 0. Garbage Cleaning (Early Stage)
    // Remove common hanging encoding errors like %C2%B1 (± sign artifact)
    let cleanUrl = rawUrl.replace(/%C2%B1$/, '').replace(/±$/, '');

    let urlObj;
    try {
      urlObj = new URL(cleanUrl);
    } catch (e) {
      if (cleanUrl.startsWith('http')) return { domain: null, fullUrl: cleanUrl };
      return { domain: null, fullUrl: null };
    }

    // 1. Check common ad URL parameters (Aggressive extraction)
    let targetUrl = urlObj.searchParams.get('adurl') ||
      urlObj.searchParams.get('url') ||
      urlObj.searchParams.get('q') ||
      urlObj.searchParams.get('dclk_url') ||
      urlObj.searchParams.get('destination') ||
      urlObj.searchParams.get('r');

    // 2. Scan ALL parameters for anything that looks like a full URL
    // [FIX] Aggressively decode and search - Google often wraps URLs multiple times
    if (!targetUrl) {
      for (const [key, value] of urlObj.searchParams.entries()) {
        let val = value;
        // Try decoding a few times if nested
        for (let j = 0; j < 3; j++) {
          if (val.includes('%')) {
            try { val = decodeURIComponent(val); } catch (e) { break; }
          } else {
            break;
          }
        }

        if (val.includes('http://') || val.includes('https://')) {
          // Find the start of the URL
          const startIdx = val.indexOf('http');
          let potentialUrl = val.substring(startIdx);

          // Cut off at common delimiters if found indiscriminately
          potentialUrl = potentialUrl.split(/[\u0000-\u001F \t\r\n]/)[0];

          // Additional cutoff for obviously wrong trailing chars
          potentialUrl = potentialUrl.replace(/%C2%B1$/, '').replace(/±$/, '');

          targetUrl = potentialUrl;
          break;
        }
      }
    }

    // 3. Base64 encoded URL detection (fallback)
    if (!targetUrl) {
      const matches = cleanUrl.match(/(aHR0[a-zA-Z0-9_\-]+)/g);
      if (matches && matches.length > 0) {
        const bestMatch = matches.sort((a, b) => b.length - a.length)[0];
        try {
          let base64 = bestMatch.replace(/-/g, '+').replace(/_/g, '/');
          while (base64.length % 4) { base64 += '='; }
          const decoded = atob(base64);
          const httpIndex = decoded.indexOf('http');
          if (httpIndex !== -1) {
            targetUrl = decoded.substring(httpIndex).split(/[\u0000-\u001F]/)[0];
          }
        } catch (e) { }
      }
    }

    // Final Domain Extraction
    const finalTarget = targetUrl || cleanUrl;

    // Final check for trailing garbage on the accepted URL
    const reallyFinalTarget = finalTarget.replace(/%C2%B1$/, '').replace(/±$/, '');

    try {
      const finalUrlObj = new URL(reallyFinalTarget);
      let hostname = finalUrlObj.hostname;
      if (hostname.startsWith('www.')) hostname = hostname.substring(4);
      return { domain: hostname, fullUrl: finalUrlObj.href };
    } catch (e) {
      return { domain: null, fullUrl: reallyFinalTarget };
    }

  } catch (e) {
    console.error("URL 파싱 최종 실패", e);
  }

  return { domain: null, fullUrl: rawUrl };
}

// 하위 호환성을 위해 남겨둠 (하지만 내부적으로 새 로직 사용 권장)
function extractCleanDomain(url) {
  const result = extractRealUrl(url);
  return result.domain !== "분석실패" ? result.domain : null;
}

// decoded url만 필요할 때
function extractDecodedUrl(url) {
  const result = extractRealUrl(url);
  return result.fullUrl;
}

/**
 * 현재 날짜를 포맷팅하여 반환합니다.
 * @returns {string} - YYYY-MM-DD HH:mm:ss
 */
function getFormattedDate() {
  const now = new Date();
  return now.getFullYear() + '-' +
    String(now.getMonth() + 1).padStart(2, '0') + '-' +
    String(now.getDate()).padStart(2, '0') + ' ' +
    String(now.getHours()).padStart(2, '0') + ':' +
    String(now.getMinutes()).padStart(2, '0') + ':' +
    String(now.getSeconds()).padStart(2, '0');
}
